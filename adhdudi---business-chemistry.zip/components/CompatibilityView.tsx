
import React, { useEffect, useState } from 'react';
import { 
  Users, AlertTriangle, Zap, CheckCircle, 
  Loader2, Share2, RefreshCw, Handshake
} from 'lucide-react';
import { CompatibilityAnalysis, Language, User, Results, Persona } from '../types';
import { getCompatibilityAnalysis } from '../geminiService';
import { getIconComponent } from '../constants';

interface CompatibilityViewProps {
  userA: { user: User; results: Results; persona: Persona };
  userB: { user: User; results: Results; persona: Persona };
  language: Language;
  onReset: () => void;
}

const CompatibilityView: React.FC<CompatibilityViewProps> = ({ userA, userB, language, onReset }) => {
  const [analysis, setAnalysis] = useState<CompatibilityAnalysis | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAnalysis = async () => {
      const result = await getCompatibilityAnalysis(
        { name: userA.user.name, persona: userA.persona, results: userA.results },
        { name: userB.user.name, persona: userB.persona, results: userB.results },
        language
      );
      setAnalysis(result);
      setLoading(false);
    };
    fetchAnalysis();
  }, [userA, userB, language]);

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-500';
    if (score >= 60) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getScoreBg = (score: number) => {
    if (score >= 80) return 'bg-green-50 border-green-200';
    if (score >= 60) return 'bg-yellow-50 border-yellow-200';
    return 'bg-red-50 border-red-200';
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-6 text-center animate-in fade-in">
        <div className="relative">
          <Handshake size={64} className="text-[#324FA2] animate-bounce" />
          <Loader2 size={32} className="absolute -top-2 -right-2 text-[#E46B3F] animate-spin" />
        </div>
        <div>
          <h2 className="text-2xl font-black text-[#324FA2]">
            {language === 'he' ? 'מנתח התאמה...' : 'Analyzing Compatibility...'}
          </h2>
          <p className="text-slate-500 font-medium mt-2">
            {language === 'he' 
              ? `בודק את הכימיה בין ${userA.user.name} ל-${userB.user.name}`
              : `Checking chemistry between ${userA.user.name} and ${userB.user.name}`}
          </p>
        </div>
      </div>
    );
  }

  if (!analysis) return null;

  return (
    <div className="space-y-6 pb-20 animate-in slide-in-from-bottom-8 duration-700">
      
      {/* Header Card */}
      <div className="bg-white p-6 rounded-[2.5rem] shadow-xl border-2 border-slate-100 text-center relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-[#324FA2] to-[#E46B3F]" />
        
        <div className="flex items-center justify-center gap-4 mb-6">
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center mb-2 shadow-sm border border-slate-100">
               {getIconComponent(userA.persona.icon, 24, "text-[#324FA2]")}
            </div>
            <span className="text-xs font-black uppercase text-slate-400 max-w-[80px] truncate">{userA.user.name}</span>
          </div>
          
          <div className="text-2xl font-black text-slate-200">VS</div>
          
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center mb-2 shadow-sm border border-slate-100">
               {getIconComponent(userB.persona.icon, 24, "text-[#E46B3F]")}
            </div>
            <span className="text-xs font-black uppercase text-slate-400 max-w-[80px] truncate">{userB.user.name}</span>
          </div>
        </div>

        <div className="space-y-2">
          <h2 className="text-sm font-black text-slate-400 uppercase tracking-widest">
            {language === 'he' ? 'ציון התאמה' : 'Compatibility Score'}
          </h2>
          <div className={`text-6xl font-black ${getScoreColor(analysis.score)} drop-shadow-sm`}>
            {analysis.score}%
          </div>
          <div className={`inline-block px-4 py-1 rounded-full text-xs font-bold ${getScoreBg(analysis.score)}`}>
            {analysis.verdict}
          </div>
        </div>
      </div>

      {/* Friction Points */}
      <div className="bg-white rounded-[2.5rem] shadow-lg border-2 border-red-100 overflow-hidden">
        <div className="bg-red-50 p-4 border-b border-red-100 flex items-center gap-2">
          <AlertTriangle className="text-red-500" size={20} />
          <h3 className="font-black text-red-800 text-sm uppercase tracking-widest">
            {language === 'he' ? 'נקודות חיכוך' : 'Friction Points'}
          </h3>
        </div>
        <div className="p-6 space-y-4">
          {analysis.friction_points.map((point, i) => (
            <div key={i} className="flex gap-3">
              <span className="text-red-300 font-black">•</span>
              <p className="text-slate-700 font-medium text-sm leading-relaxed">{point}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Synergies */}
      <div className="bg-white rounded-[2.5rem] shadow-lg border-2 border-green-100 overflow-hidden">
        <div className="bg-green-50 p-4 border-b border-green-100 flex items-center gap-2">
          <Zap className="text-green-600" size={20} />
          <h3 className="font-black text-green-800 text-sm uppercase tracking-widest">
            {language === 'he' ? 'סינרגיות' : 'Synergies'}
          </h3>
        </div>
        <div className="p-6 space-y-4">
          {analysis.synergies.map((point, i) => (
            <div key={i} className="flex gap-3">
              <CheckCircle className="text-green-400 shrink-0" size={16} />
              <p className="text-slate-700 font-medium text-sm leading-relaxed">{point}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <button 
          onClick={onReset} 
          className="w-full py-4 bg-slate-100 text-slate-500 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-slate-200 transition-colors flex items-center justify-center gap-2"
        >
          <RefreshCw size={16} />
          {language === 'he' ? 'התחל מחדש' : 'Start Over'}
        </button>
      </div>
    </div>
  );
};

export default CompatibilityView;
